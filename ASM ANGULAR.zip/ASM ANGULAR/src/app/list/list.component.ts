import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ProjectService } from '../service/project.service';

@Component({
  selector: 'app-list',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './list.component.html',
  styleUrl: './list.component.css',
})
export class ListComponent {
  listProjects: any;
  constructor(private service: ProjectService) {}

  ngOnInit(): void {
    this.service.List().subscribe((res) => {
      this.listProjects = res;
    });
  }
  onDelete(id: number): void {
    if (confirm('Bạn có muốn xóa không?')) {
      this.service.Remove(id).subscribe((res) => {
        alert('xoa thanh cong');
        this.ngOnInit();
      });
    }
  }
}
