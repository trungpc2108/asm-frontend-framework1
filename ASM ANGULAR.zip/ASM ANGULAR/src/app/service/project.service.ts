import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ProjectService {
  apiUrl = 'http://localhost:3000/projects';
  constructor(private http: HttpClient) {}
  List() {
    return this.http.get(this.apiUrl);
  }
  getprojectById(id: any) {
    return this.http.get(this.apiUrl + '/' + id);
  }
  Remove(id: any) {
    return this.http.delete(this.apiUrl + '/' + id);
  }
  Create(data: any) {
    return this.http.post(this.apiUrl, data);
  }
  Update(id: any, data: any) {
    return this.http.put(this.apiUrl + '/' + id, data);
  }
}
