import { Routes } from '@angular/router';
import { ListComponent } from './list/list.component';
import { CreateComponent } from './create/create.component';
import { DetailComponent } from './detail/detail.component';
import { EditComponent } from './edit/edit.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { AppComponent } from './app.component';
import { ProjectComponent } from './project/project.component';
import { UserComponent } from './user/user.component';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';

export const routes: Routes = [
  {
    path: 'register',
    component: RegisterComponent,
    title: 'Register',
  },
  {
    path: 'login',
    component: LoginComponent,
    title: 'Login',
  },
  {
    path: '',
    component: HomeComponent,
  },
  {
    path: 'list',
    component: ListComponent,
    title: 'List',
  },
  {
    path: 'create',
    component: CreateComponent,
    title: 'Create',
  },
  {
    path: 'detail/:id',
    component: DetailComponent,
    title: 'Detail',
  },
  {
    path: 'edit/:id',
    component: EditComponent,
    title: 'Edit',
  },
  {
    path: 'home',
    component: HomeComponent,
    title: 'Home',
  },
  {
    path: 'admin',
    children: [
      {
        path: 'projects',
        children: [
          {
            path: 'list',
            component: ListComponent,
          },
        ],
      },
      {
        path: 'users',
        component: UserComponent,
      },
    ],
  },
  {
    path: '**', //xử lý khi ng dùng nhập vào một route không hợp lệ
    component: NotFoundComponent,
  },
];
