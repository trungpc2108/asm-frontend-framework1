import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ProjectService } from '../service/project.service';

@Component({
  selector: 'app-create',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './create.component.html',
  styleUrl: './create.component.css',
})
export class CreateComponent {
  constructor(private service: ProjectService, private router: Router) {}

  onCreate(data: any): void {
    this.service.Create(data).subscribe((res) => {
      alert('Thêm mới thành công');
      this.router.navigate(['/list']);
    });
  }
}
