import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../service/auth.service';
import { Router } from '@angular/router';
import { error } from 'console';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, CommonModule],

  templateUrl: './register.component.html',
  styleUrl: './register.component.css',
})
export class RegisterComponent {
  constructor(private auth: AuthService, private router: Router) {}
  onSubmit = (data: any) => {
    try {
      this.auth.register(data).subscribe((res) => {
        alert('Đăng ký thành công');
        this.router.navigate(['/login']);
      });
    } catch (error) {
      console.log(error);
    }
  };
}
