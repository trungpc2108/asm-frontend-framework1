import { HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ProjectService } from '../service/project.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-edit',
  standalone: true,
  imports: [FormsModule, HttpClientModule, CommonModule],
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css'],
})
export class EditComponent implements OnInit {
  project: any = {};
  id: number = 0;

  constructor(
    private route: ActivatedRoute,
    private service: ProjectService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    console.log(this.id);
    this.service.getprojectById(this.id).subscribe({
      next: (res) => {
        this.project = res;
      },
      error: (err) => {
        console.error(err);
        alert('Đã xảy ra lỗi khi lấy dự án');
      },
    });
  }

  onEdit(data: any): void {
    this.service.Update(this.id, data).subscribe({
      next: () => {
        alert('Cập nhật thành công');
        this.router.navigate(['/list']);
      },
      error: (err) => {
        console.error(err);
        alert('Đã xảy ra lỗi khi cập nhật dự án');
      },
    });
  }
}
